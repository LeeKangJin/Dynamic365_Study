﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RestfulTest
{
    public class ServiceClass
    {
    }
    public class InputGetDate
    {
        public int a { get; set; }
        public int b { get; set; }
    }
}